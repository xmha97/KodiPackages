#!/usr/bin/env python
# -*- coding: UTF-8 -*-

#
# Imports
#
from future import standard_library
standard_library.install_aliases()
from os.path import join
from sys import argv
import json
from time import gmtime, strftime, strptime
import urllib.error
from urllib.request import urlopen
from urllib.parse import parse_qs, urlparse, quote_plus
from xml.dom.minidom import parseString
from xbmc import translatePath
import xbmcaddon
from xbmcgui import Dialog, ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory

ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONVERSION = ADDON.getAddonInfo('version')
CWD = ADDON.getAddonInfo('path').decode("utf-8")
LANGUAGE = ADDON.getLocalizedString

DataLink = 'http://navahang.me/webservice/GetMp3?type=Featured&from=0&to=20'

class LoadLister:

        def __init__(self, url):
                self.url = url

        def addLink(self, name, url, image = '', info = {}, totalItems = 0):
                item = ListItem(name.encode('utf-8'), iconImage = image, thumbnailImage = image)
                item.setProperty('mimetype', 'audio/mpeg')
                item.setInfo('music', info)
                return addDirectoryItem(int(argv[1]), url, item, False, totalItems)

        def buildIndex(self):
                rdLink = 'http://173.236.47.154:2199/rpc/radionavahang/streaminfo.get'
                request = urllib.request.Request(rdLink, headers={'User-Agent' : 'Kodi'})
                response = urllib.request.urlopen(request)
                json_text = response.read()
                loaded_json = json.loads(json_text)
                otext = loaded_json['data'][0]['track']
                self.addLink('[B]' + otext['title'] + "[/B][CR]" + otext['artist'], loaded_json['data'][0]['tuneinurl'], otext['imageurl'], {'Artist': otext['artist'],'Title': otext['title'],'Album': otext['album'] if otext['album']!='' else 'Single'})

                request = urllib.request.Request(DataLink, headers={'User-Agent' : 'Kodi'})
                response = urllib.request.urlopen(request)
                json_text = response.read()
                loaded_json = json.loads(json_text)
                for item in loaded_json:
                        self.addLink('[B]' + item['song_name'] + '[/B][CR]' + item['artist_name'], item['download'], item['image'], {'Artist': item['artist_name'],'Title': item['song_name'],'Album': 'Single'})

        def run(self, handle):
                endOfDirectory(int(handle))

if __name__ == '__main__':
        try:
                appClass = LoadLister(DataLink)
                appClass.buildIndex()
                appClass.run(argv[1])
                
        except urllib2.HTTPError as err:
                xbmcgui.Dialog().ok(ADDONNAME, LANGUAGE(30001) % err.code, LANGUAGE(30000))

        except:
                xbmcgui.Dialog().ok(ADDONNAME, LANGUAGE(30002), LANGUAGE(30000))
